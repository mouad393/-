import { User } from '../types';

const REGISTRY_KEY = 'taawasol_registry';

// Helper to get the full registry object
const getRegistry = (): Record<string, User> => {
  try {
    const data = localStorage.getItem(REGISTRY_KEY);
    return data ? JSON.parse(data) : {};
  } catch (e) {
    console.error("Failed to load registry", e);
    return {};
  }
};

// Register a new user into the local "database"
export const registerUserInStorage = (user: User) => {
  const registry = getRegistry();
  registry[user.uniqueNumber] = user;
  localStorage.setItem(REGISTRY_KEY, JSON.stringify(registry));
};

// Find a user by their unique 8-digit number
export const findUserByNumber = (uniqueNumber: string): User | null => {
  const registry = getRegistry();
  return registry[uniqueNumber] || null;
};

// Find a user by their internal UUID (helper for incoming messages)
export const findUserById = (uuid: string): User | null => {
  const registry = getRegistry();
  return Object.values(registry).find(u => u.id === uuid) || null;
};

import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

let aiClient: GoogleGenAI | null = null;

// Initialize lazily to avoid errors if API key is missing initially
const getClient = () => {
  if (!aiClient && apiKey) {
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
};

export const generateAIResponse = async (
  history: { role: 'user' | 'model'; text: string }[],
  lastMessage: string,
  customSystemInstruction?: string
): Promise<string> => {
  const client = getClient();
  if (!client) return "عذراً، خدمة الذكاء الاصطناعي غير متوفرة حالياً.";

  try {
    const model = "gemini-2.5-flash";
    
    // Construct prompt history
    // We are simulating a user in the chat app.
    const defaultInstruction = "أنت مساعد ذكي ومفيد داخل تطبيق دردشة عربي يسمى 'تواصل'. تحدث بلهجة ودية وعربية فصحى مبسطة. إجاباتك يجب أن تكون قصيرة ومناسبة للمحادثة الفورية.";
    const systemInstruction = customSystemInstruction || defaultInstruction;

    const contents = [
      ...history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      })),
      {
        role: 'user',
        parts: [{ text: lastMessage }]
      }
    ];

    const response = await client.models.generateContent({
      model,
      contents: contents as any, 
      config: {
        systemInstruction,
        maxOutputTokens: 300,
      }
    });

    return response.text || "عذراً، لم أتمكن من فهم ذلك.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "حدث خطأ أثناء الاتصال بالخادم.";
  }
};
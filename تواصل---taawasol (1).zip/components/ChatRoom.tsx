import React, { useState, useEffect, useRef } from 'react';
import { Contact, Message, User } from '../types';

interface ChatRoomProps {
  user: User;
  contact: Contact;
  messages: Message[];
  onSendMessage: (text: string) => void;
  onBack: () => void;
  isTyping?: boolean;
}

const ChatRoom: React.FC<ChatRoomProps> = ({ user, contact, messages, onSendMessage, onBack, isTyping }) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText);
    setInputText('');
  };

  return (
    <div className="h-full flex flex-col bg-[#e5ddd5]">
      {/* Header */}
      <div className="bg-primary-600 text-white px-4 py-3 flex items-center justify-between shadow-md z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="md:hidden p-1 -mr-2 hover:bg-white/20 rounded-full">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 transform rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
             </svg>
          </button>
          <img src={contact.avatar} alt={contact.name} className="w-10 h-10 rounded-full border border-white/30" />
          <div>
            <h3 className="font-bold text-sm leading-tight">{contact.name}</h3>
            <p className="text-xs text-primary-100 opacity-90">
                {isTyping ? 'يكتب الآن...' : (contact.isOnline ? 'متصل الآن' : 'آخر ظهور منذ فترة')}
            </p>
          </div>
        </div>
        {/* Removed Call Button */}
      </div>

      {/* Messages Area */}
      {/* Changed background from image to CSS pattern */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-4" 
        style={{ 
            backgroundColor: "#f0f9ff",
            backgroundImage: "radial-gradient(#bae6fd 1.5px, transparent 1.5px)",
            backgroundSize: "24px 24px"
        }}
      >
        {/* Encryption notice similar to WhatsApp */}
        <div className="flex justify-center mb-4">
            <span className="bg-white/80 backdrop-blur-sm text-gray-500 text-xs px-3 py-1.5 rounded-lg shadow-sm text-center max-w-xs border border-primary-100">
                🔒 الرسائل في هذه المحادثة مشفرة تماماً بين الطرفين. لا يمكن لأي طرف ثالث قراءتها.
            </span>
        </div>

        {messages.map((msg) => {
          const isMe = msg.senderId === user.id;
          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-start' : 'justify-end'}`}>
              <div 
                className={`
                  relative max-w-[80%] px-4 py-2 rounded-lg shadow-sm text-sm
                  ${isMe ? 'bg-white text-gray-800 rounded-tr-none border border-gray-100' : 'bg-primary-100 text-gray-800 rounded-tl-none border border-primary-200'}
                `}
              >
                <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                <div className={`text-[10px] mt-1 flex gap-1 ${isMe ? 'justify-end text-gray-400' : 'justify-start text-primary-800/60'}`}>
                   <span>{new Date(msg.timestamp).toLocaleTimeString('ar-SA', {hour: '2-digit', minute:'2-digit'})}</span>
                   {isMe && <span>✓✓</span>}
                </div>
                
                {/* Bubble Tail SVG */}
                <span className={`absolute top-0 w-3 h-3 ${isMe ? '-right-2' : '-left-2'}`}>
                   <svg viewBox="0 0 8 13" width="8" height="13" className={`${isMe ? 'fill-white' : 'fill-primary-100'}`}>
                      <path opacity="0.13" fill="#0000000" d="M1.533,3.568L8,12.193V1H2.812 C1.042,1,0.474,2.156,1.533,3.568z"></path>
                      <path d={isMe ? "M-0.004,3.605L-0.004,0.068L8.004,0.068L-0.004,3.605Z" : "M8.004,3.605L8.004,0.068L-0.004,0.068L8.004,3.605Z"} transform={isMe ? "" : "scale(-1, 1) translate(-8, 0)"}></path>
                   </svg>
                </span>
              </div>
            </div>
          );
        })}
        
        {isTyping && (
             <div className="flex justify-end">
                <div className="bg-white rounded-lg rounded-tl-none px-4 py-3 shadow-sm">
                    <div className="flex gap-1">
                        <span className="w-2 h-2 bg-primary-600 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                        <span className="w-2 h-2 bg-primary-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                        <span className="w-2 h-2 bg-primary-600 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                    </div>
                </div>
             </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white px-2 py-2 flex items-end gap-2 border-t border-gray-100">
        <button className="p-3 text-gray-400 hover:bg-gray-100 hover:text-primary-500 rounded-full transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
        </button>
        
        <form onSubmit={handleSend} className="flex-1 flex items-center gap-2 bg-white rounded-full">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="اكتب رسالة..."
            className="w-full py-3 px-4 bg-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary-100 text-right"
            dir="auto"
          />
          <button 
            type="submit"
            disabled={!inputText.trim()}
            className={`p-3 rounded-full transition-all transform ${inputText.trim() ? 'bg-primary-600 text-white hover:scale-105 shadow-md' : 'bg-gray-200 text-gray-400'}`}
          >
             <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${!inputText.trim() && 'rotate-12'}`} viewBox="0 0 20 20" fill="currentColor">
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
             </svg>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatRoom;
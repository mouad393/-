import React, { useState } from 'react';
import { Contact, User } from '../types';
import { findUserByNumber } from '../services/storageService';

interface ChatListProps {
  currentUser: User;
  contacts: Contact[];
  onSelectContact: (contact: Contact) => void;
  onAddContact: (id: string) => void;
  onLogout: () => void;
}

const ChatList: React.FC<ChatListProps> = ({ currentUser, contacts, onSelectContact, onAddContact, onLogout }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newContactId, setNewContactId] = useState('');
  const [error, setError] = useState('');

  // Helper function to safely truncate text
  const truncate = (str: string | undefined, n: number) => {
    if (!str) return '';
    return (str.length > n) ? str.substr(0, n - 1) + '...' : str;
  };

  // Helper to format time (e.g., 10:30 PM)
  const formatTime = (timestamp?: number) => {
    if (!timestamp) return '';
    return new Date(timestamp).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
  };

  // Helper to convert Arabic digits to English
  const normalizeNumber = (str: string) => {
    return str.replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d).toString());
  };

  const handleAddClick = () => {
    setNewContactId('');
    setError('');
    setShowAddModal(true);
  };

  const handleAddSubmit = () => {
    const cleanNumber = normalizeNumber(newContactId.trim());
    
    if (!cleanNumber) {
      setError('الرجاء إدخال رقم');
      return;
    }

    if (cleanNumber.length < 4) {
       setError('الرقم قصير جداً');
       return;
    }

    if (cleanNumber === currentUser.uniqueNumber) {
      setError('لا يمكنك إضافة نفسك');
      return;
    }

    if (contacts.find(c => c.uniqueNumber === cleanNumber)) {
      setError('هذا الصديق موجود بالفعل في قائمتك');
      return;
    }

    // Check locally first
    const userExists = findUserByNumber(cleanNumber);
    
    if (!userExists) {
      // Allow it anyway for P2P (Cross-Browser)
      // We don't show an error anymore, we just proceed.
      // The App.tsx logic will handle creating a "Remote Contact" placeholder.
    }

    onAddContact(cleanNumber);
    setNewContactId('');
    setShowAddModal(false);
    setError('');
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-white sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img src={currentUser.avatar} alt="Me" className="w-10 h-10 rounded-full object-cover ring-2 ring-primary-100" />
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
          </div>
          <div>
            <h2 className="font-bold text-gray-800 leading-tight">الدردشات</h2>
            <p className="text-xs text-primary-600 font-mono">#{currentUser.uniqueNumber}</p>
          </div>
        </div>
        <button onClick={onLogout} className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
        </button>
      </div>

      {/* Search / Add */}
      <div className="px-4 py-3">
        <button 
          onClick={handleAddClick}
          className="w-full bg-primary-50 text-primary-700 font-medium py-3 rounded-xl flex items-center justify-center gap-2 hover:bg-primary-100 transition-colors border border-primary-100"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          إضافة جهة اتصال جديدة
        </button>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto">
        {contacts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center p-6">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <p className="text-gray-500 mb-6">لا توجد محادثات بعد.<br/>أضف رقم صديقك للدردشة معه عبر المتصفحات المختلفة.</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-50">
            {contacts.map(contact => (
              <li key={contact.id}>
                <button 
                  onClick={() => onSelectContact(contact)}
                  className="w-full px-6 py-4 flex items-center gap-4 hover:bg-gray-50 transition-colors text-right group"
                >
                  <div className="relative flex-shrink-0">
                    <img src={contact.avatar} alt={contact.name} className="w-14 h-14 rounded-full object-cover group-hover:scale-105 transition-transform duration-200" />
                    {contact.isOnline && (
                      <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full"></span>
                    )}
                    {contact.isBot && (
                         <span className="absolute -top-1 -left-1 bg-blue-500 text-white text-[10px] px-1.5 py-0.5 rounded-full shadow-sm">AI</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline mb-1">
                      <h3 className="text-base font-bold text-gray-800 truncate">{contact.name}</h3>
                      <span className="text-xs text-gray-400 font-medium">{formatTime(contact.lastMessageTime)}</span>
                    </div>
                    <p className="text-sm text-gray-500 truncate group-hover:text-primary-600 transition-colors">
                      {truncate(contact.lastMessage, 35) || <span className="text-gray-300 italic">انقر للبدء بالمحادثة</span>}
                    </p>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-sm animate-in fade-in zoom-in duration-200">
                <h3 className="text-lg font-bold text-gray-800 mb-2">إضافة صديق</h3>
                <p className="text-sm text-gray-500 mb-4">أدخل الرقم الخاص بصديقك (يمكن أن يكون على متصفح أو جهاز آخر).</p>
                
                {error && (
                  <div className="bg-red-50 text-red-600 text-xs p-3 rounded-lg mb-4 flex items-start gap-2 leading-relaxed">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mt-0.5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    <span>{error}</span>
                  </div>
                )}

                <input 
                    type="text" 
                    value={newContactId}
                    onChange={(e) => {
                        setNewContactId(e.target.value);
                        setError('');
                    }}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddSubmit()}
                    placeholder="مثال: 83920192"
                    className="w-full p-3 border rounded-xl mb-4 focus:ring-2 focus:ring-primary-500 outline-none font-mono text-center text-lg tracking-widest"
                    maxLength={8}
                />
                
                <div className="flex gap-3">
                    <button 
                        onClick={() => setShowAddModal(false)}
                        className="flex-1 py-2.5 rounded-xl bg-gray-100 text-gray-700 font-medium hover:bg-gray-200"
                    >
                        إلغاء
                    </button>
                    <button 
                        onClick={handleAddSubmit}
                        disabled={!newContactId.trim()}
                        className={`flex-1 py-2.5 rounded-xl text-white font-bold transition-colors ${
                          !newContactId.trim() ? 'bg-gray-300 cursor-not-allowed' : 'bg-primary-600 hover:bg-primary-700'
                        }`}
                    >
                        إضافة
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ChatList;
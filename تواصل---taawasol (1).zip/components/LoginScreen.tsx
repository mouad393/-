import React, { useState, useRef } from 'react';
import { User } from '../types';
import { registerUserInStorage } from '../services/storageService';

interface LoginScreenProps {
  onRegister: (user: User) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onRegister }) => {
  const [name, setName] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsLoading(true);
    
    // Simulate network delay for "generating ID"
    setTimeout(() => {
      const generatedId = Math.floor(10000000 + Math.random() * 90000000).toString();
      const newUser: User = {
        id: crypto.randomUUID(),
        name: name,
        avatar: image || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=14b8a6&color=fff`,
        uniqueNumber: generatedId,
        bio: 'مستخدم جديد في تواصل'
      };
      
      // Save to "Backend" (LocalStorage)
      registerUserInStorage(newUser);
      
      onRegister(newUser);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-600 to-primary-800 p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500"></div>
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">أهلاً بك في تواصل</h1>
          <p className="text-gray-500">سجل دخولك بإسمك وصورتك فقط، واحصل على رقم خاص.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Image Upload */}
          <div className="flex flex-col items-center">
            <div 
              className="w-32 h-32 rounded-full bg-gray-100 border-4 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-primary-500 hover:bg-primary-50 transition-all relative overflow-hidden group"
              onClick={() => fileInputRef.current?.click()}
            >
              {image ? (
                <img src={image} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <div className="text-center text-gray-400 group-hover:text-primary-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mx-auto mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="text-xs font-medium">اضف صورة</span>
                </div>
              )}
              {image && (
                 <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                   <span className="text-white text-xs font-bold">تغيير</span>
                 </div>
              )}
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleImageUpload}
            />
          </div>

          {/* Name Input */}
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">الاسم المستعار</label>
            <input
              type="text"
              id="username"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-all bg-gray-50 focus:bg-white text-right"
              placeholder="اكتب اسمك هنا..."
              required
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading || !name.trim()}
              className={`w-full py-4 rounded-xl text-white font-bold shadow-lg transform transition-all ${
                isLoading || !name.trim() 
                ? 'bg-gray-300 cursor-not-allowed' 
                : 'bg-primary-600 hover:bg-primary-700 hover:-translate-y-1 shadow-primary-500/30'
              }`}
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                   <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  جاري الإنشاء...
                </span>
              ) : 'إنشاء حسابي الخاص'}
            </button>
          </div>

          <p className="text-xs text-center text-gray-400 mt-4">
            بالتسجيل أنت توافق على سياسة الخصوصية. لا نطلب رقم هاتفك أبداً.
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginScreen;
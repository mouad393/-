import React, { useEffect } from 'react';
import { User } from '../types';
import confetti from 'canvas-confetti';

interface SuccessScreenProps {
  user: User;
  onContinue: () => void;
}

const SuccessScreen: React.FC<SuccessScreenProps> = ({ user, onContinue }) => {
  
  useEffect(() => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-primary-50 p-4">
      <div className="bg-white rounded-3xl shadow-xl p-8 w-full max-w-sm text-center relative">
        <div className="absolute -top-12 left-1/2 transform -translate-x-1/2">
          <div className="w-24 h-24 rounded-full border-4 border-white shadow-md overflow-hidden">
            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
          </div>
        </div>
        
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-1">مرحباً، {user.name}!</h2>
          <p className="text-green-600 font-medium mb-6">تم إنشاء حسابك بنجاح</p>
          
          <div className="bg-gray-100 rounded-xl p-6 mb-6 border-2 border-dashed border-gray-300 relative">
            <p className="text-sm text-gray-500 mb-2">رقمك الخاص الجديد</p>
            <p className="text-4xl font-mono font-bold text-primary-700 tracking-wider select-all">
              {user.uniqueNumber}
            </p>
            <p className="text-xs text-gray-400 mt-2">شارك هذا الرقم مع أصدقائك ليتواصلوا معك</p>
          </div>

          <button 
            onClick={onContinue}
            className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold hover:bg-primary-700 transition-colors"
          >
            ابدأ الدردشة
          </button>
        </div>
      </div>
    </div>
  );
};

export default SuccessScreen;
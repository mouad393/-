export interface User {
  id: string;
  name: string;
  avatar: string; // Base64 string
  uniqueNumber: string; // The generated "phone number" equivalent
  bio?: string;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: number;
  isSystem?: boolean;
}

export interface Contact {
  id: string;
  name: string;
  avatar: string;
  uniqueNumber: string;
  isOnline: boolean;
  lastMessage?: string;
  lastMessageTime?: number;
  isBot?: boolean; // Identify if this is the Gemini AI contact
  isReal?: boolean; // Identify if this is a real registered user (same device)
}

export enum AppScreen {
  LOGIN,
  ONBOARDING_SUCCESS,
  DASHBOARD,
  CHAT_ROOM
}

export interface BroadcastPayload {
  type: 'CHAT_MESSAGE' | 'PING' | 'PONG';
  fromUser: User;
  toUserId: string; // The ID (uuid) of the recipient (might be unknown/placeholder)
  toUniqueNumber: string; // The Public Number of the recipient (always known)
  text: string;
  timestamp: number;
}
import React, { useState, useEffect, useRef } from 'react';
import LoginScreen from './components/LoginScreen';
import SuccessScreen from './components/SuccessScreen';
import ChatList from './components/ChatList';
import ChatRoom from './components/ChatRoom';
import { AppScreen, Contact, Message, User, BroadcastPayload } from './types';
import { generateAIResponse } from './services/geminiService';
import { findUserByNumber } from './services/storageService';
// @ts-ignore
import { Peer } from 'peerjs';

// Default AI Bot contact
const BOT_CONTACT: Contact = {
  id: 'gemini-bot',
  name: 'المساعد الذكي',
  // Updated background color to match new primary blue (0ea5e9)
  avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Gemini&backgroundColor=0ea5e9',
  uniqueNumber: '00000001',
  isOnline: true,
  lastMessage: 'مرحباً بك في تواصل! أنا مساعدك الذكي.',
  lastMessageTime: Date.now(),
  isBot: true
};

const PEER_PREFIX = 'taawasol-v2-';

export default function App() {
  const [screen, setScreen] = useState<AppScreen>(AppScreen.LOGIN);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeContact, setActiveContact] = useState<Contact | null>(null);
  
  // Data Stores
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [messages, setMessages] = useState<Record<string, Message[]>>({});
  const [typingStatus, setTypingStatus] = useState<Record<string, boolean>>({});
  
  // Broadcast Channel Ref (Same Browser/Tab)
  const channelRef = useRef<BroadcastChannel | null>(null);
  // PeerJS Ref (Cross Browser/Device)
  const peerRef = useRef<any>(null);

  // Load user from local storage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('taawasol_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      setScreen(AppScreen.DASHBOARD);
      initializeDefaultContacts();
      initializeCommunication(user);
    }

    return () => {
        channelRef.current?.close();
        // We don't destroy peer on unmount immediately to avoid quick reconnections during dev HMR,
        // but for production cleanliness:
        if (peerRef.current) {
            peerRef.current.destroy();
        }
    };
  }, []);

  const initializeCommunication = (user: User) => {
      // 1. Initialize Broadcast Channel (Local Tabs)
      if (!channelRef.current) {
          const channel = new BroadcastChannel('taawasol_chat');
          channelRef.current = channel;
          channel.onmessage = (event) => {
              handleIncomingMessage(event.data as BroadcastPayload);
          };
      }

      // 2. Initialize PeerJS (Cross Browser)
      if (!peerRef.current || peerRef.current.destroyed) {
          const myPeerId = `${PEER_PREFIX}${user.uniqueNumber}`;
          
          const peer = new Peer(myPeerId, {
              debug: 1,
              config: {
                iceServers: [
                  { urls: 'stun:stun.l.google.com:19302' },
                  { urls: 'stun:global.stun.twilio.com:3478' }
                ]
              }
          });

          peer.on('open', (id: string) => {
              console.log('My Peer ID is: ' + id);
          });

          peer.on('connection', (conn: any) => {
              conn.on('data', (data: any) => {
                  handleIncomingMessage(data as BroadcastPayload);
              });
              conn.on('error', (err: any) => {
                  console.warn('Incoming connection error:', err);
              });
          });

          // Reconnection Logic
          peer.on('disconnected', () => {
              console.log('PeerJS disconnected.');
              // Attempt to reconnect only if not destroyed
              if (peer && !peer.destroyed) {
                  peer.reconnect();
              }
          });

          peer.on('error', (err: any) => {
             console.warn('PeerJS Error:', err.type, err);
             // If fatal error or lost connection, try reconnecting after delay
             if (err.type === 'network' || err.type === 'server-error' || err.message?.includes('Lost connection')) {
                 setTimeout(() => {
                     if (peer && !peer.destroyed && peer.disconnected) {
                         peer.reconnect();
                     }
                 }, 3000);
             }
          });

          peerRef.current = peer;
      }
  };

  // Generic handler for messages from anywhere (Tab or Peer)
  const handleIncomingMessage = (payload: BroadcastPayload) => {
      const myUserStr = localStorage.getItem('taawasol_user');
      if (!myUserStr) return;
      const myUser = JSON.parse(myUserStr) as User;
      
      const isForMe = payload.toUniqueNumber === myUser.uniqueNumber || payload.toUserId === myUser.id;
      
      if (!isForMe) return;

      const sender = payload.fromUser;

      if (payload.type === 'PING') {
          sendSignal(sender, 'PONG', '');
      }

      setContacts(prevContacts => {
          const existingIndex = prevContacts.findIndex(c => c.uniqueNumber === sender.uniqueNumber);
          
          if (existingIndex > -1) {
              const updated = [...prevContacts];
              const oldContact = updated[existingIndex];
              
              updated[existingIndex] = {
                ...oldContact,
                id: sender.id,
                name: sender.name,
                avatar: sender.avatar,
                isOnline: true,
                lastMessage: payload.type === 'CHAT_MESSAGE' ? payload.text : oldContact.lastMessage,
                lastMessageTime: payload.type === 'CHAT_MESSAGE' ? payload.timestamp : oldContact.lastMessageTime
              };
              return updated;
          } else {
              const initialMsg = payload.type === 'CHAT_MESSAGE' ? payload.text : 'طلب اتصال جديد...';
              
              const newContact: Contact = {
                  id: sender.id,
                  name: sender.name,
                  avatar: sender.avatar,
                  uniqueNumber: sender.uniqueNumber,
                  isOnline: true,
                  lastMessage: initialMsg,
                  lastMessageTime: payload.timestamp,
                  isReal: true,
                  isBot: false
              };
              return [newContact, ...prevContacts];
          }
      });

      if (payload.type === 'CHAT_MESSAGE') {
          const newMessage: Message = {
              id: crypto.randomUUID(),
              senderId: sender.id, 
              text: payload.text,
              timestamp: payload.timestamp
          };

          setMessages(prev => ({
              ...prev,
              [sender.id]: [...(prev[sender.id] || []), newMessage]
          }));
      }
  };

  const safePeerConnect = (targetUniqueNumber: string) => {
      const peer = peerRef.current;
      if (!peer || peer.destroyed) return null;

      // Fix: If disconnected, try to reconnect but don't throw "Cannot connect to new Peer"
      if (peer.disconnected) {
          console.log('Peer is disconnected, attempting to reconnect before sending...');
          peer.reconnect();
          return null; // We cannot return a connection yet, prevents the crash
      }

      try {
        const targetPeerId = `${PEER_PREFIX}${targetUniqueNumber}`;
        return peer.connect(targetPeerId);
      } catch (error) {
        console.warn("Peer connect threw error:", error);
        return null;
      }
  };

  const sendSignal = (targetUser: {uniqueNumber: string, id: string}, type: 'PING' | 'PONG', text: string = '') => {
      if (!currentUser) return;
      
      const payload: BroadcastPayload = {
          type,
          fromUser: currentUser,
          toUserId: targetUser.id,
          toUniqueNumber: targetUser.uniqueNumber,
          text,
          timestamp: Date.now()
      };
      
      // Send via PeerJS
      if (peerRef.current) {
          const conn = safePeerConnect(targetUser.uniqueNumber);
          if (conn) {
              conn.on('open', () => {
                  conn.send(payload);
                  setTimeout(() => conn.close(), 2000);
              });
              conn.on('error', (e: any) => console.warn("Signal connection error", e));
          }
      }
      
      // Send via Local Broadcast
      if (channelRef.current) channelRef.current.postMessage(payload);
  };

  const initializeDefaultContacts = () => {
     setContacts(prev => {
         if (prev.find(c => c.id === BOT_CONTACT.id)) return prev;
         return [BOT_CONTACT, ...prev];
     });
     
     setMessages(prev => {
         if (prev[BOT_CONTACT.id]) return prev;
         return {
             ...prev,
             [BOT_CONTACT.id]: [{
                 id: 'init-msg',
                 senderId: BOT_CONTACT.id,
                 text: 'مرحباً بك! أنا هنا لمساعدتك وتجربة التطبيق. يمكنك التحدث معي في أي وقت.',
                 timestamp: Date.now()
             }]
         }
     });
  };

  const handleRegister = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('taawasol_user', JSON.stringify(user));
    setScreen(AppScreen.ONBOARDING_SUCCESS);
    initializeCommunication(user);
  };

  const handleContinueToApp = () => {
    initializeDefaultContacts();
    setScreen(AppScreen.DASHBOARD);
  };

  const handleSelectContact = (contact: Contact) => {
    setActiveContact(contact);
    setScreen(AppScreen.CHAT_ROOM);
  };

  const handleAddContact = (uniqueNumber: string) => {
    if (!uniqueNumber.trim()) return;
    
    const realUser = findUserByNumber(uniqueNumber);
    let newContact: Contact;

    if (realUser) {
        newContact = {
            id: realUser.id,
            name: realUser.name,
            uniqueNumber: realUser.uniqueNumber,
            avatar: realUser.avatar,
            isOnline: true,
            lastMessage: 'تمت الإضافة، ابدأ المحادثة',
            lastMessageTime: Date.now(),
            isBot: false,
            isReal: true
        };
    } else {
        const placeholderId = `remote-${uniqueNumber}`;
        newContact = {
            id: placeholderId, 
            name: `مستخدم ${uniqueNumber}`,
            uniqueNumber: uniqueNumber,
            avatar: `https://ui-avatars.com/api/?name=${uniqueNumber}&background=random`,
            isOnline: false,
            lastMessage: 'جاري الاتصال...',
            lastMessageTime: Date.now(),
            isBot: false,
            isReal: true
        };
        
        setTimeout(() => {
            sendSignal({ uniqueNumber, id: placeholderId }, 'PING');
        }, 500);
    }
    
    setContacts(prev => [newContact, ...prev]);
    setActiveContact(newContact);
    setScreen(AppScreen.CHAT_ROOM);
  };

  const handleSendMessage = async (text: string) => {
    if (!currentUser || !activeContact) return;

    const newMessage: Message = {
      id: crypto.randomUUID(),
      senderId: currentUser.id,
      text,
      timestamp: Date.now()
    };

    setMessages(prev => ({
      ...prev,
      [activeContact.id]: [...(prev[activeContact.id] || []), newMessage]
    }));

    setContacts(prev => prev.map(c => 
        c.id === activeContact.id 
        ? { ...c, lastMessage: text, lastMessageTime: Date.now() } 
        : c
    ));

    if (activeContact.isReal) {
        const payload: BroadcastPayload = {
            type: 'CHAT_MESSAGE',
            fromUser: currentUser,
            toUserId: activeContact.id,
            toUniqueNumber: activeContact.uniqueNumber,
            text: text,
            timestamp: Date.now()
        };

        if (channelRef.current) {
            channelRef.current.postMessage(payload);
        }

        if (peerRef.current) {
            const conn = safePeerConnect(activeContact.uniqueNumber);
            if (conn) {
                conn.on('open', () => {
                    conn.send(payload);
                    setTimeout(() => conn.close(), 2000);
                });
                conn.on('error', (e: any) => console.log("Message send error", e));
            }
        }
        return;
    }

    if (activeContact.isBot) {
      setTypingStatus(prev => ({ ...prev, [activeContact.id]: true }));
      
      const chatHistory = (messages[activeContact.id] || []).map(m => ({
          role: m.senderId === currentUser.id ? 'user' as const : 'model' as const,
          text: m.text
      }));

      try {
          const replyText = await generateAIResponse(chatHistory, text);
          
          const replyMessage: Message = {
              id: crypto.randomUUID(),
              senderId: activeContact.id,
              text: replyText,
              timestamp: Date.now()
          };

          setMessages(prev => ({
              ...prev,
              [activeContact.id]: [...(prev[activeContact.id] || []), replyMessage]
          }));

          setContacts(prev => prev.map(c => 
              c.id === activeContact.id 
              ? { ...c, lastMessage: replyText, lastMessageTime: Date.now() } 
              : c
          ));

      